# Foodies
A clean MVVM architecure application
